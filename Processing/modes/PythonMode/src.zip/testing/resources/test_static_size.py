size(10, 10)
print 'OK'
exit()
